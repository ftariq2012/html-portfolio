console.clear();
Splitting();